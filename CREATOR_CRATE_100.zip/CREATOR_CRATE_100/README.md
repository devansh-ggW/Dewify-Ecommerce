# CREATOR CRATE 100
By DEWIFY. 50 website templates + 50 design templates.

## What is included
- `50_Website_Templates/` - 50 single-file HTML websites (businesses, weddings, celebrations, food, beauty, events, health, education, portfolios, home services).
- `50_Design_Templates/` - 50 editable SVG designs: business cards, invitations, certificates, tickets, vouchers, flyers, posters, social graphics, menus and more. Each has layered, named groups (background, headline, details, footer...) with live text.

## Website templates
- Each site is ONE `.html` file with CSS and JavaScript embedded. No frameworks, npm or build process. Double-click to open in Chrome, Edge or Firefox.
- Responsive for desktop, tablet and mobile, with mobile menu, smooth scrolling, FAQ and a contact modal (front-end only: connect the form to your own email or form service before going live).

## Design templates
- Open in Figma, Illustrator, Inkscape, Affinity or Canva, or edit as text in any code editor. Uses system fonts; swap `font-family` for your brand fonts.

## How to edit
1. Open a file in any code editor.
2. Replace the placeholder names, dates, prices, phone and email. Website colours are the `--bg --fg --ac --sf` variables at the top of `<style>`; fonts are `--hf` and `--bf`.
3. Upload the `.html` to any web host, or export the `.svg` to PNG or PDF.
All names and contact details are fictional placeholders. Replace them before publishing.
