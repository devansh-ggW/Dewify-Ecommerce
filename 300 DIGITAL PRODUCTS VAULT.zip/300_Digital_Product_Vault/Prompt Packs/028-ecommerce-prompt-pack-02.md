# Ecommerce Prompt Pack 02

**Mission:** Product Research.

**What this pack is for:** evaluate products using customer need and market signals.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Ecommerce practitioner. Build a one-page action brief for **product research** focused on evaluate products using customer need and market signals. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 2

Turn this rough input into a structured Ecommerce plan for **product research**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 3

Create a decision matrix for evaluate products using customer need and market signals. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 4

Design a reusable workflow for evaluate products using customer need and market signals. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 5

Generate 12 distinct options for evaluate products using customer need and market signals for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 6

Audit this existing Ecommerce work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 7

Build a 7-day execution sprint for evaluate products using customer need and market signals. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 8

Create a customer or user profile specifically for evaluate products using customer need and market signals. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 9

Write a quality-control checklist for evaluate products using customer need and market signals. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for evaluate products using customer need and market signals. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 11

Create three contrasting versions of a Ecommerce asset for evaluate products using customer need and market signals: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 12

Act as a skeptical reviewer of a product research strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 13

Build a swipe-file style reference sheet for evaluate products using customer need and market signals. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 14

Create a before-and-after improvement exercise for evaluate products using customer need and market signals. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Prompt 15

Design a reusable master prompt for evaluate products using customer need and market signals. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Focus on customer understanding, clear product information, and honest communication.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
