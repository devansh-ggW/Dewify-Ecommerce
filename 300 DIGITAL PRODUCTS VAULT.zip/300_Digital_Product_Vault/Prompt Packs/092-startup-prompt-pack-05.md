# Startup Prompt Pack 05

**Mission:** Founder Operations.

**What this pack is for:** build lightweight systems for running a young startup.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Startup practitioner. Build a one-page action brief for **founder operations** focused on build lightweight systems for running a young startup. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 2

Turn this rough input into a structured Startup plan for **founder operations**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 3

Create a decision matrix for build lightweight systems for running a young startup. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 4

Design a reusable workflow for build lightweight systems for running a young startup. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 5

Generate 12 distinct options for build lightweight systems for running a young startup for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 6

Audit this existing Startup work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 7

Build a 7-day execution sprint for build lightweight systems for running a young startup. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 8

Create a customer or user profile specifically for build lightweight systems for running a young startup. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 9

Write a quality-control checklist for build lightweight systems for running a young startup. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for build lightweight systems for running a young startup. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 11

Create three contrasting versions of a Startup asset for build lightweight systems for running a young startup: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 12

Act as a skeptical reviewer of a founder operations strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 13

Build a swipe-file style reference sheet for build lightweight systems for running a young startup. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 14

Create a before-and-after improvement exercise for build lightweight systems for running a young startup. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Prompt 15

Design a reusable master prompt for build lightweight systems for running a young startup. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has some existing results and wants to improve them.
State assumptions clearly and do not fabricate validation evidence or customer demand.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
