# Education Prompt Pack 05

**Mission:** Learning Improvement.

**What this pack is for:** diagnose learning friction and improve the learning process.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Education practitioner. Build a one-page action brief for **learning improvement** focused on diagnose learning friction and improve the learning process. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 2

Turn this rough input into a structured Education plan for **learning improvement**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 3

Create a decision matrix for diagnose learning friction and improve the learning process. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 4

Design a reusable workflow for diagnose learning friction and improve the learning process. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 5

Generate 12 distinct options for diagnose learning friction and improve the learning process for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 6

Audit this existing Education work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 7

Build a 7-day execution sprint for diagnose learning friction and improve the learning process. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 8

Create a customer or user profile specifically for diagnose learning friction and improve the learning process. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 9

Write a quality-control checklist for diagnose learning friction and improve the learning process. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for diagnose learning friction and improve the learning process. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 11

Create three contrasting versions of a Education asset for diagnose learning friction and improve the learning process: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 12

Act as a skeptical reviewer of a learning improvement strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 13

Build a swipe-file style reference sheet for diagnose learning friction and improve the learning process. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 14

Create a before-and-after improvement exercise for diagnose learning friction and improve the learning process. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Prompt 15

Design a reusable master prompt for diagnose learning friction and improve the learning process. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has some existing results and wants to improve them.
Optimize for learning outcomes, learner clarity, feedback, and appropriate difficulty.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
