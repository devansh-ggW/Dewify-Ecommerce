# Copywriting Prompt Pack 02

**Mission:** Landing Pages.

**What this pack is for:** build persuasive landing-page copy from a product brief.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Copywriting practitioner. Build a one-page action brief for **landing pages** focused on build persuasive landing-page copy from a product brief. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 2

Turn this rough input into a structured Copywriting plan for **landing pages**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 3

Create a decision matrix for build persuasive landing-page copy from a product brief. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 4

Design a reusable workflow for build persuasive landing-page copy from a product brief. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 5

Generate 12 distinct options for build persuasive landing-page copy from a product brief for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 6

Audit this existing Copywriting work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 7

Build a 7-day execution sprint for build persuasive landing-page copy from a product brief. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 8

Create a customer or user profile specifically for build persuasive landing-page copy from a product brief. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 9

Write a quality-control checklist for build persuasive landing-page copy from a product brief. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for build persuasive landing-page copy from a product brief. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 11

Create three contrasting versions of a Copywriting asset for build persuasive landing-page copy from a product brief: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 12

Act as a skeptical reviewer of a landing pages strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 13

Build a swipe-file style reference sheet for build persuasive landing-page copy from a product brief. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 14

Create a before-and-after improvement exercise for build persuasive landing-page copy from a product brief. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Prompt 15

Design a reusable master prompt for build persuasive landing-page copy from a product brief. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Prioritize clarity and one reader action; avoid unsupported claims.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
