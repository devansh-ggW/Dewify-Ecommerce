# Ai Video Prompt Pack 05

**Mission:** Video Iteration.

**What this pack is for:** diagnose weak generations and improve them systematically.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Ai Video practitioner. Build a one-page action brief for **video iteration** focused on diagnose weak generations and improve them systematically. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 2

Turn this rough input into a structured Ai Video plan for **video iteration**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 3

Create a decision matrix for diagnose weak generations and improve them systematically. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 4

Design a reusable workflow for diagnose weak generations and improve them systematically. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 5

Generate 12 distinct options for diagnose weak generations and improve them systematically for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 6

Audit this existing Ai Video work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 7

Build a 7-day execution sprint for diagnose weak generations and improve them systematically. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 8

Create a customer or user profile specifically for diagnose weak generations and improve them systematically. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 9

Write a quality-control checklist for diagnose weak generations and improve them systematically. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for diagnose weak generations and improve them systematically. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 11

Create three contrasting versions of a Ai Video asset for diagnose weak generations and improve them systematically: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 12

Act as a skeptical reviewer of a video iteration strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 13

Build a swipe-file style reference sheet for diagnose weak generations and improve them systematically. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 14

Create a before-and-after improvement exercise for diagnose weak generations and improve them systematically. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Prompt 15

Design a reusable master prompt for diagnose weak generations and improve them systematically. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has some existing results and wants to improve them.
Make the output concrete enough to hand to a video-generation workflow.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
