# Sales Prompt Pack 02

**Mission:** Lead Qualification.

**What this pack is for:** identify which leads deserve attention and why.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Sales practitioner. Build a one-page action brief for **lead qualification** focused on identify which leads deserve attention and why. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 2

Turn this rough input into a structured Sales plan for **lead qualification**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 3

Create a decision matrix for identify which leads deserve attention and why. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 4

Design a reusable workflow for identify which leads deserve attention and why. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 5

Generate 12 distinct options for identify which leads deserve attention and why for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 6

Audit this existing Sales work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 7

Build a 7-day execution sprint for identify which leads deserve attention and why. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 8

Create a customer or user profile specifically for identify which leads deserve attention and why. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 9

Write a quality-control checklist for identify which leads deserve attention and why. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for identify which leads deserve attention and why. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 11

Create three contrasting versions of a Sales asset for identify which leads deserve attention and why: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 12

Act as a skeptical reviewer of a lead qualification strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 13

Build a swipe-file style reference sheet for identify which leads deserve attention and why. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 14

Create a before-and-after improvement exercise for identify which leads deserve attention and why. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Prompt 15

Design a reusable master prompt for identify which leads deserve attention and why. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user has a small budget and wants practical outputs.
Use consultative, non-deceptive language and preserve buyer choice.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
