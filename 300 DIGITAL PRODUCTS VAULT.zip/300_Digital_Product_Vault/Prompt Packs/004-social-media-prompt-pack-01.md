# Social Media Prompt Pack 01

**Mission:** Content Strategy.

**What this pack is for:** build a social content strategy for a specific audience.

Replace bracketed fields with your own details before running a prompt.

## Prompt 1

Act as a senior Social Media practitioner. Build a one-page action brief for **content strategy** focused on build a social content strategy for a specific audience. Include objective, audience, constraints, deliverables, success metrics, and the first three actions.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 2

Turn this rough input into a structured Social Media plan for **content strategy**: [PASTE NOTES]. Preserve useful details, flag missing information, and finish with a practical execution checklist.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 3

Create a decision matrix for build a social content strategy for a specific audience. Compare 5 realistic approaches using criteria for impact, effort, cost, speed, risk, and fit. Explain the assumptions behind each score without inventing evidence.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 4

Design a reusable workflow for build a social content strategy for a specific audience. Show the exact sequence, required inputs, AI tasks, human review points, output format, and what should be saved for reuse.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 5

Generate 12 distinct options for build a social content strategy for a specific audience for this audience: [AUDIENCE]. Give each a different angle, why it matters, what it requires, and one inexpensive test.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 6

Audit this existing Social Media work: [PASTE WORK]. Find the 7 biggest weaknesses, explain the likely consequence of each, and rewrite the two weakest sections.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 7

Build a 7-day execution sprint for build a social content strategy for a specific audience. Assign one meaningful outcome to each day, include a realistic time budget, and add a definition of done.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 8

Create a customer or user profile specifically for build a social content strategy for a specific audience. Cover situation, needs, frustrations, desired outcome, objections, language, trust signals, and purchase or adoption triggers.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 9

Write a quality-control checklist for build a social content strategy for a specific audience. Organize checks into accuracy, clarity, usefulness, consistency, accessibility, and final polish. Make every check observable.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 10

Take this objective — [OBJECTIVE] — and convert it into a measurable project for build a social content strategy for a specific audience. Define milestones, leading indicators, lagging indicators, review dates, and triggers for changing the plan.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 11

Create three contrasting versions of a Social Media asset for build a social content strategy for a specific audience: minimal, bold, and premium. Describe how the strategy, structure, language, and intended response differ.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 12

Act as a skeptical reviewer of a content strategy strategy. List 10 questions that could expose weak assumptions. Answer only where the supplied information supports an answer; otherwise flag the gap.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 13

Build a swipe-file style reference sheet for build a social content strategy for a specific audience. Give categories to collect, patterns worth studying, what to annotate, and how to extract reusable principles without copying protected work.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 14

Create a before-and-after improvement exercise for build a social content strategy for a specific audience. Start with a deliberately weak example, diagnose it line by line, then produce a stronger version and explain the changes.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Prompt 15

Design a reusable master prompt for build a social content strategy for a specific audience. It should make an AI clarify assumptions, execute the task, self-check against a custom rubric, and return a clean final answer. Leave bracketed fields for customization.

**Pack context:** Assume the user is starting from zero and has limited time.
Keep platform behavior in mind and avoid engagement bait.

## Usage note

Each prompt is designed to stand alone and can be sold individually, bundled, customized, or adapted according to the license attached to your product. Review AI output before using it in real work.
