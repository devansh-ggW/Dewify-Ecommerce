# 300 Digital Product Vault

A library of **300 core digital assets** for customization, packaging, and resale under the license terms you choose.

## Folder structure

- `Website Templates/` — **100 standalone website templates**. Every folder contains exactly one file: `index.html`. CSS and JavaScript are embedded inside the HTML.
- `Editable Design Templates/` — **100 editable PowerPoint (`.pptx`) designs** across business cards, ebook covers, invitations, flyers, social graphics, posters, resumes, certificates, menus, presentations, and related use cases.
- `Prompt Packs/` — **100 standalone prompt packs**, with **15 non-repetitive prompts per pack = 1,500 prompts total**. Every pack can be sold individually.

## Website template format

Open any `index.html` directly in a browser. Edit it to change copy, colors, links, sections, and branding. No separate CSS or JavaScript files are included in a website folder.

## Prompt-pack format

Each prompt pack is its own Markdown file with 15 distinct prompts. The packs cover different missions, workflows, audits, planning exercises, critiques, customer research, and reusable master prompts rather than repeating the same generic formula.

## Resale / commercial-use license template

These files are supplied as editable source materials. A seller may customize, rebrand, bundle, market, and resell them according to the license they attach to the product. Do not describe a transfer of copyright ownership unless you are actually making a copyright assignment.

A seller who wants customers to receive further resale or redistribution rights should state those rights explicitly in the customer-facing license.

**Important:** Any third-party fonts, libraries, images, trademarks, APIs, or other components added by a seller are the seller's responsibility to license separately. This pack does not grant rights to third-party materials.

This README is a practical template, not legal advice. Have the final license reviewed for the laws and marketplaces relevant to your business.

## Asset count

- Website templates: 100
- Editable design templates: 100
- Prompt packs: 100
- Prompts inside packs: 1,500
- **Core assets: 300**
