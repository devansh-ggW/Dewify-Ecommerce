# CREATOR STASH 700
By DEWIFY. 350 website templates + 350 design templates = 700 templates.

## What is included
- `350_Website_Templates/` - 350 single-file HTML websites (businesses, weddings, celebrations, food, beauty, events, health, education, portfolios, home services).
- `350_Design_Templates/` - 350 editable SVG designs in 13 layout styles: cards, invitations, certificates, tickets, vouchers, flyers, posters, social graphics, menus and more. Each has named layers (background, headline, details, footer...) with live text.

## Website templates
- Each site is ONE `.html` file with CSS and JavaScript embedded. No frameworks, npm or build process. Double-click to open in Chrome, Edge or Firefox.
- Responsive for desktop, tablet and mobile, with mobile menu, smooth scrolling, FAQ and a contact modal (front-end only: connect the form to your own email or form service before going live).

## Design templates
- Open in Figma, Illustrator, Inkscape, Affinity or Canva, or edit as text in any code editor. Uses system fonts; swap `font-family` for your brand fonts.

## How to edit
1. Open a file in any code editor.
2. Replace the placeholder names, dates, prices, phone and email. Website colours are the `--bg --fg --ac --sf` variables at the top of `<style>`; fonts are `--hf` and `--bf`.
3. Upload the `.html` to any web host, or export the `.svg` to PNG or PDF.
All names and contact details are fictional placeholders. Replace them before publishing.
