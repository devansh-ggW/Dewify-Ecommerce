# CREATOR BUNDLE 500
By DEWIFY. 250 website templates + 250 design templates.

## What is included
- `250_Website_Templates/` - 250 single-file HTML websites across businesses, weddings, celebrations, food, beauty, events, health, education, portfolios and home services.
- `250_Design_Templates/` - 250 editable SVG designs (cards, invitations, flyers, posters, social graphics, menus, certificates, vouchers, banners and more).

## Website templates
- Each site is ONE `.html` file. CSS and JavaScript are embedded inside it (`<style>` and `<script>`).
- No frameworks, no npm, no build process, no external files. Double-click to open in Chrome, Edge or Firefox.
- Responsive for desktop, tablet and mobile. Includes mobile menu, smooth scrolling, FAQ, and a working contact modal (front-end only: connect the form to your own email or form service before going live).

## Design templates
- Editable SVG with real text and shapes. Open in Figma, Illustrator, Inkscape, Affinity or Canva, or edit as text in any code editor.
- Fonts are system fonts so files open anywhere. Swap `font-family` values for your brand fonts.

## How to edit
1. Open a file in any code editor (VS Code, Notepad, etc).
2. Replace placeholder names, dates, prices, phone, email and text. Website colours are the `--bg --fg --ac --sf` variables at the top of `<style>`; fonts are `--hf` (headings) and `--bf` (body).
3. Upload the `.html` file to any web host, or share the `.svg`/export it to PNG or PDF.
Placeholder names and contact details are fictional. Replace them with your own before publishing.
